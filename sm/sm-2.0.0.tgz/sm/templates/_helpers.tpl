{{/*
Expand the name of the chart.
*/}}
{{- define "sm.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "sm.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "sm.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "sm.labels" -}}
helm.sh/chart: {{ include "sm.chart" . }}
{{ include "sm.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "sm.selectorLabels" -}}
app.kubernetes.io/name: {{ include "sm.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "sm.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "sm.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{/*
Shared image tag resolution.
*/}}
{{- define "sm.imageTag" -}}
{{- $global := (index .Values "global") | default dict -}}
{{- $imageTag := .Values.imageTag | default (index $global "imageTag") -}}
{{- required "Setting value 'global.imageTag' (or legacy 'imageTag') is required!" $imageTag -}}
{{- end }}

{{/*
Shared image pull policy resolution.
*/}}
{{- define "sm.imagePullPolicy" -}}
{{- $global := (index .Values "global") | default dict -}}
{{- .Values.imagePullPolicy | default (index $global "imagePullPolicy") | default "IfNotPresent" -}}
{{- end }}

{{/*
Image for SM Server
*/}}
{{- define "sm.serverimage" -}}
image: "{{ required "Setting value 'server.image.repository' is required!" .Values.server.image.repository }}:{{ include "sm.imageTag" . }}"
{{- end }}

{{/*
Image for SM Agent
*/}}
{{- define "sm.agentimage" -}}
image: "{{ required "Setting value 'agent.image.repository' is required!" .Values.agent.image.repository }}:{{ include "sm.imageTag" . }}"
{{- end }}